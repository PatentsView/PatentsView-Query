<?php
    header("Access-Control-Allow-Origin: *");
    header("Cache-Control: private, must-revalidate, max-age=0");
    header("Pragma: no-cache");
    header("Expires: Fri, 4 Jun 2010 12:00:00 GMT");
    header("Location: thank-you.php?q=" . $_POST["q"]);
    exit();
?>
