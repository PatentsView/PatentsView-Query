<?php
$mysql_host = "host";
$mysql_username = "username";
$mysql_password = "password";
?>
