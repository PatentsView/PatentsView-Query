<?php 
$key="recaptcha-key"; 
?>